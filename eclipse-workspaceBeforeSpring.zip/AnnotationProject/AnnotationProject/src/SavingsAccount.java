

@DevelopedBy(name="Anoop", version=3)
public class  SavingsAccount {   
	
	

	float balance;
	int acno;
	String name;
	
	public SavingsAccount() {
		super();
	
	}
	
	public SavingsAccount(float balance) {
		super();
		this.balance = balance;
	}
	
	public SavingsAccount(int acno, String name) {
		super();
		this.acno = acno;
		this.name = name;
	}

	public SavingsAccount(float balance, int acno, String name) {
		super();
		this.balance = balance;
		this.acno = acno;
		this.name = name;
	}


	public void withdraw() {
		System.out.println("withdrawing...");
	}
	public void deposit() {
		System.out.println("depositing....");
	}
	
	public void transfer() {
		System.out.println("transferring...");
	}

}
