import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Iterator;

public class RunIt {
	public static void main(String[] args) {
		
		
		SavingsAccount saObj = new SavingsAccount();
		//Reflection and Annotation
		
		
		//Object crawler|spider
		
		Class mirror  = saObj.getClass();
		
		Annotation anno[] =mirror.getAnnotations();
		for (Annotation annotation : anno) {
			System.out.println("annotation is "+annotation);
			
			if(annotation instanceof DevelopedBy) {
				DevelopedBy db = (DevelopedBy) annotation;
				if(db.name().equals("Anoop")) {
					System.out.println("Loading the class...");
					if(db.version()==3) {
						System.out.println("Running the methods...");
						saObj.withdraw();
					}
					else {
						System.out.println("Expected version is 3");
					}
				}
				else {
					System.out.println("Expected to be developed by Anoop...");
				}
			}
		
		}
		
		
		Method methods[] = mirror.getMethods();
		for (Method method : methods) {
			System.out.println("method : "+method.getName());
		}
		
		Constructor cto[] = mirror.getConstructors();
		for (Constructor constructor : cto) {
			System.out.println("Constructor with "+constructor.getParameterCount()+" arguments");
		}
		
		
		
		
	
	}
}
/*
 * 	Object 
 *
 * to print the string representation of the object
 *		toString()
 *
 *Equal object policy
 *		hashCode()
 *		equals();
 *
 *deep cloning vs shallow cloning
 *		clone();
 *
 *get the object of class Class
 *		getClass();
 *
 *
 *Interthread communication
 * 		wait()
 * 		wait(,)
 * 		wait(,,)
 * 		notify()
 * 		notifyAll()
 * 
 * Garbage collection
 * 		finalize()
 */











