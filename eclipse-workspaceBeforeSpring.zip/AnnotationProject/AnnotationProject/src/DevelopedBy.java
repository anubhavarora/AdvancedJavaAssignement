import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(TYPE)
public @interface DevelopedBy {

	String name();

	int version();

}
/*class DevelopedByImpl implements DevelopedBy
{
	String _name;
	int _version;
	
	public String name() {
		return _name;
	}
	
	public int version() {
		return _version;	
	}
	
	
}

class Testing
{
	void fun() {
		DevelopedBy d = new DevelopedByImpl();
		
	}
}

*/



