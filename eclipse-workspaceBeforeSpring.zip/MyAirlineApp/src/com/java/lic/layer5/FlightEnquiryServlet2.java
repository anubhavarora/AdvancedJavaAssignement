package com.java.lic.layer5;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.java.lic.layer2.Flight;
import com.java.lic.layer3.FlightRepositoryImpl2;

/**
 * Servlet implementation class FlightEnquiryServlet2
 */
public class FlightEnquiryServlet2 extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	FlightRepositoryImpl2 flight2 = new FlightRepositoryImpl2();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightEnquiryServlet2() 
    {
        super();
        System.out.println("constructor of FlighEnquiryServlet2...");
    }

    public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("INIT2");
	}
    
    
    public void destroy() 
	{
		super.destroy();
		System.out.println("destroy2");
	}
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doGet : "+request.getRemoteHost()+"   Port : "+ request.getRemotePort());
		String source = request.getParameter("src");
		String target = request.getParameter("trg");
		String ts = request.getParameter("jdate");
		
		String dateString =	request.getParameter("jdate");
		CharSequence  charSeq = dateString.subSequence(0, dateString.length());
		
		LocalDate when = LocalDate.parse(charSeq);
		
		System.out.println("dateString : "+dateString);
		
		
		System.out.println("Source : "+ source);
		System.out.println("Target : "+ target);
		
		
		PrintWriter pw = response.getWriter();
		pw.println("Customer is searching for flight from "+source+" to "+target);
		response.setContentType("text/HTML");
		
		List<Flight> foundFlights = flight2.searchFlights(source, target, when);
		
		//Request Tracking
		request.setAttribute("flightKey1", foundFlights);
		
		RequestDispatcher rd = request.getRequestDispatcher("ShowAvailableFlights.jsp");
		rd.forward(request, response);
		
		
		//Session Tracking
		HttpSession session = request.getSession(true);
		session.setAttribute("flightKey2", foundFlights);
		
		//Application Context
		ServletContext ctx = getServletContext();
		ctx.setAttribute("flightKey3", foundFlights);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doPost.... FLightEnquiryServlet2");
		doGet(request, response);
	}

}
