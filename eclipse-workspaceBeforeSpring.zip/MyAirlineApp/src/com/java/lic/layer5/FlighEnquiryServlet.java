package com.java.lic.layer5;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.lic.layer2.Flight;
import com.java.lic.layer3.FlightRepositoryImpl;
import com.java.lic.layer3.FlightRepositoryImpl2;


/**
 * Servlet implementation class FlighEnquiryServlet
 */
//enquiry
public class FlighEnquiryServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    
	FlightRepositoryImpl flightRepo = new FlightRepositoryImpl();
	
	FlightRepositoryImpl2 flight2 = new FlightRepositoryImpl2();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlighEnquiryServlet() 
    {
        super();
        System.out.println("constructor of FlighEnquiryServlet...");
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException 
	{
		System.out.println("INIT");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() 
	{
		super.destroy();
		System.out.println("destroy");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doGet : "+request.getRemoteHost()+"   Port : "+ request.getRemotePort());
		String source = request.getParameter("src");
		String target = request.getParameter("trg");
		String ts = request.getParameter("jdate");
		
		String dateString =	request.getParameter("jdate");
		CharSequence  charSeq = dateString.subSequence(0, dateString.length());
		
		LocalDate when = LocalDate.parse(charSeq);
		
		System.out.println("dateString : "+dateString);
		
		
		System.out.println("Source : "+ source);
		System.out.println("Target : "+ target);
		
		
		PrintWriter pw = response.getWriter();
		pw.println("Customer is searching for flight from "+source+" to "+target);
		response.setContentType("text/HTML");
		
//		List<Flight> flightList = flightRepo.searchFlights();
//		pw.println("<table>"
//				+ "<tr>"
//				+ "<th>Flight Number</th>"
//				+"<th>Source</th>"
//				+ "<th>Destination</th>"
//				+ "<th>Departure Date</th>"
//				+ "</tr>");
//		int var = 0;
//		for(Flight theFLight : flightList)
//		{
//			if(theFLight.getFlightSource().equalsIgnoreCase(source) && theFLight.getFlightDestination().equalsIgnoreCase(target))
//			{
//				var++;
//				
//				pw.println("<tr>");
//					pw.println("<td>"+theFLight.getFlightNumber()+"</td>");
//					pw.println("<td>"+theFLight.getFlightSource()+"</td>");
//					pw.println("<td>"+theFLight.getFlightDestination()+"</td>");
//					pw.println("<td>"+theFLight.getFlightDepartureDate()+"</td>");
//				pw.println("</tr>");
//					
////				pw.println("Flight id : " + theFLight.getFlightNumber() + " is availabe from " + theFLight.getFlightSource() + " and " + theFLight.getFlightDestination() + 
////						" departing at "+ theFLight.getFlightDepartureDate());
////				
//			}
//		}
//		if (var == 0)
//		{
//			pw.println("<tr>");
//			pw.println("<td colspan='4'>NA</td>");
//			
//			pw.println("</tr>");
//		}
//		pw.println("</table>");
		
		
//		pw.println("<table border=3 cellspacing=5 cellpadding=5>");
//		List<Flight> foundFlights = flightRepo.searchFlights(source, target);
//		for(Flight theFlight : foundFlights) 
//		{
//			pw.println("<tr>");
//			pw.println("<td>"+theFlight.getFlightNumber()+"</td>");
//			pw.println("<td>"+theFlight.getFlightSource()+"</td>");
//			pw.println("<td>"+theFlight.getFlightDestination()+"</td>");
//			pw.println("<td>"+theFlight.getFlightDepartureDate()+"</td>");
//			pw.println("</tr>");
//		}
//		pw.println("</table>");
//		pw.println("<a href='http://localhost:8080/MyAirlineApp'> Back </a>");
		
		pw.println("<table border=3 cellspacing=5 cellpadding=5>");
//		List<Flight> foundFlights = flight2.searchFlights(source, target);
		List<Flight> foundFlights = flight2.searchFlights(source, target, when);
		
		for(Flight theFlight : foundFlights) {
				pw.println("<tr>");
				pw.println("<td>"+theFlight.getFlightNumber()+"</td>");
				pw.println("<td>"+theFlight.getFlightSource()+"</td>");
				pw.println("<td>"+theFlight.getFlightDestination()+"</td>");
				pw.println("<td>"+theFlight.getFlightDepartureDate()+"</td>");
				pw.println("</tr>");
		}
		pw.println("</table>");
		pw.println("<a href='http://localhost:8080/MyAirlineApp'> Back </a>");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("doPost.... FLightEnquiryServlet");
		doGet(request, response);
	}

}
