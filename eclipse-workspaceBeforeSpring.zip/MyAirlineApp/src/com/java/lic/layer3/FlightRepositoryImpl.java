package com.java.lic.layer3;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.java.lic.layer2.Flight;

public class FlightRepositoryImpl implements FlightRepository 
{

	ArrayList<Flight> flightList = new ArrayList<Flight>(); // Empty List
	
	public FlightRepositoryImpl() 
	{
		System.out.println("FlightRepositoryImpl() .... constructor");
		
////		Flight flight11 = new Flight(101, "Mumbai", "London", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight1 = new Flight(201, "Mumbai", "London", Timestamp.valueOf("2021-11-13 22:45:00"));
//		Flight flight2 = new Flight(301, "Mumbai", "London", Timestamp.valueOf("2021-11-14 21:45:00"));
//		
//		Flight flight12 = new Flight(102, "Mumbai", "Paris", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight3 = new Flight(202, "Mumbai", "Paris", Timestamp.valueOf("2021-12-14 23:45:00"));
//		Flight flight4 = new Flight(302, "Mumbai", "Paris", Timestamp.valueOf("2021-11-15 23:45:00"));
//		
//		
//		Flight flight13 = new Flight(103, "Mumbai", "New York", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight14 = new Flight(104, "Mumbai", "New Delhi", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight15 = new Flight(105, "Mumbai", "Kolkata", Timestamp.valueOf("2021-11-11 23:45:00"));
//		Flight flight16 = new Flight(106, "Mumbai", "Chandigarh", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight17 = new Flight(107, "London", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight18 = new Flight(108, "Paris", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight19 = new Flight(109, "New York", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight20 = new Flight(110, "New Delhi", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight21 = new Flight(111, "Kolkata", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		Flight flight22 = new Flight(112, "Chandigarh", "Mumbai", Timestamp.valueOf("2021-11-12 23:45:00"));
//		
//		flightList.add(flight1);
//		flightList.add(flight2);
//		flightList.add(flight3);
//		flightList.add(flight4);
//		flightList.add(flight11);
//		flightList.add(flight12);
//		flightList.add(flight13);
//		flightList.add(flight14);
//		flightList.add(flight15);
//		flightList.add(flight16);
//		flightList.add(flight17);
//		flightList.add(flight18);
//		flightList.add(flight19);
//		flightList.add(flight20);
//		flightList.add(flight21);
//		flightList.add(flight22);
		
		
		
		
	}
	@Override
	public void insertFlight(Flight flight) 
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void updateFlight(Flight flight) 
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteFlight(int flightNumber) 
	{
		// TODO Auto-generated method stub

	}

	@Override
	public Flight searchFlight(int flightNumber)
	{
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public List<Flight> searchFlights() 
	{
		return flightList;
	}
	@Override
	public List<Flight> searchFlights(String source, String target) 
	{
		List<Flight> foundFlights = new ArrayList<Flight>();
		
		for(Flight theFlight : flightList) {
			if(theFlight.getFlightSource().equalsIgnoreCase(source) && theFlight.getFlightDestination().equals(target)) 
			{
				foundFlights.add(theFlight);
			}
		}
		
		return foundFlights;
	}
	@Override
	public List<Flight> searchFlights(String source, String target, LocalDate  timeStamp) 
	{
		// TODO Auto-generated method stub
		return null;
	}

}
