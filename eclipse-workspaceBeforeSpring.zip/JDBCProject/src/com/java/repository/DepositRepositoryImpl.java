package com.java.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.entity.Department;

public class DepositRepositoryImpl implements DepartmentRepository 
{
	List<Department> deptList = new ArrayList<Department>();
	Connection conn;
	
	public DepositRepositoryImpl()
	{
		try 
		{
			// 1. Load the driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver Registered ...");
			
			
			// 2. Connect to database
			
			this.conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "tiger");
			
			System.out.println("Connected to the DB : "+conn);
			
			// 3. Statement
			
			
			
			// 4. Make your desired statement
			
			
			
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void insertDepartment(Department dept) 
	{
		System.out.println("Inside insertDepartment");
		try 
		{
			PreparedStatement pst = conn.prepareStatement("insert into dept values (?,?,?)");
			pst.setInt(1, dept.getDepartmentNumber());
			pst.setString(2, dept.getDepartmentName());
			pst.setString(3, dept.getDepartmentLocation());
			
			int rows = pst.executeUpdate();
			
			System.out.println("Record inserted . . . : "+rows);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void updateDepartment(Department dept)
	{
		try 
		{
			PreparedStatement pst = conn.prepareStatement("update dept set dname=?, loc= ? where deptno =?");
			
			pst.setString(1, dept.getDepartmentName());
			pst.setString(2, dept.getDepartmentLocation());
			pst.setInt(3, dept.getDepartmentNumber());
			
			int rows = pst.executeUpdate();
			
			System.out.println("Record updated . . . : "+rows);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void deleteDepartment(int deptno) 
	{
		try 
		{
			PreparedStatement pst = conn.prepareStatement("delete from dept where deptno =?");

			pst.setInt(1, deptno);
			
			int rows = pst.executeUpdate();
			
			System.out.println("Record deleted . . . : "+rows);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public Department selectDepartment(int deptno) 
	{
		Department deptObj = null;
		try 
		{
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from dept where deptno = "+deptno);

			if(rs.next())
			{
				deptObj = new Department();
				deptObj.setDepartmentNumber(rs.getInt(1));
				deptObj.setDepartmentName(rs.getString(2));
				deptObj.setDepartmentLocation(rs.getString(3));
				deptList.add(deptObj);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return deptObj;
	}

	@Override
	public List<Department> selectDepartments() 
	{
		Statement stmt;
		try 
		{
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from dept");
			System.out.println(" Result set : "+rs);
			while(rs.next())
			{
				Department deptObj = new Department();
				deptObj.setDepartmentNumber(rs.getInt(1));
				deptObj.setDepartmentName(rs.getString(2));
				deptObj.setDepartmentLocation(rs.getString(3));
				deptList.add(deptObj);
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return deptList;
	}
	
}
