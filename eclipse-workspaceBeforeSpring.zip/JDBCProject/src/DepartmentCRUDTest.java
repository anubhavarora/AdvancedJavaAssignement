import java.util.List;

import com.java.entity.*;
import com.java.repository.*;

public class DepartmentCRUDTest 
{
	public static void main(String[] args) 
	{
		DepositRepositoryImpl deptRepo = new DepositRepositoryImpl();
		Department dept = new Department();
		
		// Insert
		
//		dept.setDepartmentLocation("MDC");
//		dept.setDepartmentName("Java training");
//		dept.setDepartmentNumber(50);
//		
//		deptRepo.insertDepartment(dept);
		
		//Update
		
//		dept.setDepartmentLocation("MDC");
//		dept.setDepartmentName("Java");
//		dept.setDepartmentNumber(50);
//		deptRepo.updateDepartment(dept);
		
		// Select All
		
		List<Department> deptList = deptRepo.selectDepartments();
		for(Department dept1 : deptList) {
			System.out.println("deptno : "+dept1.getDepartmentNumber());
			System.out.println("dname  : "+dept1.getDepartmentName());
			System.out.println("loc    : "+dept1.getDepartmentLocation());
		}
		System.out.println("--------------------");
		
		
		// Select one
		dept = deptRepo.selectDepartment(10);
		System.out.println("deptno : "+dept.getDepartmentNumber());
		System.out.println("dname  : "+dept.getDepartmentName());
		System.out.println("loc    : "+dept.getDepartmentLocation());
		System.out.println("--------------------");
		
		// delete
		
		deptRepo.deleteDepartment(50);
			
		
	}

}
