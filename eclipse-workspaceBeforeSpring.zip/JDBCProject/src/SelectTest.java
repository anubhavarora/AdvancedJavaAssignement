import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.java.entity.Department;

public class SelectTest 
{

	public static void main(String[] args)
	{
		
		try 
		{
			// 1. Load the driver
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver Registered ...");
			
			
			// 2. Connect to database
			
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "tiger");
			
			System.out.println("Connected to the DB : "+conn);
			
			// 3. Statement
			
			Statement stmt = conn.createStatement();
			System.out.println("Statment created");
			
			// 4. Make your desired statement
			
			
			ResultSet rs = stmt.executeQuery("select * from dept");
			System.out.println(" Result set : "+rs);
			while(rs.next())
			{
				Department deptObj = new Department();
				deptObj.setDepartmentNumber(rs.getInt(1));
				deptObj.setDepartmentName(rs.getString(2));
				deptObj.setDepartmentLocation(rs.getString(3));
				
				System.out.println(deptObj.getDepartmentNumber()+"----"+deptObj.getDepartmentName()+"----"+deptObj.getDepartmentLocation());
			}
			
			// 5. Closing connection
			
			conn.close();
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

}
