package strategy2.joinedtableperclass;

import java.util.List;

import org.junit.Test;

import com.java.repo.BaseRepository;


public class BillingDetailsTest {

	@Test
	public void testCase1() 
	{
		
		BankAccount bankAcc = new BankAccount();
		bankAcc.setOwner("Majrul Ansari");
		bankAcc.setNumber("12345");
		bankAcc.setBankName("ICICI Bank");

		CreditCard creditCard = new CreditCard();
		creditCard.setOwner("Majrul Ansari");
		creditCard.setNumber("412901234567890");
		creditCard.setType("VISA");
		creditCard.setExpiryMonth("12");
		creditCard.setExpiryYear("2099");
		
		BaseRepository dao = new BaseRepository();
		dao.merge(bankAcc);
		dao.merge(creditCard);
		
	}
	
	@Test
	public void testCase2() {
		BaseRepository dao = new BaseRepository();
		List<BillingDetails> list = dao.findAll("BillingDetails2");
		System.out.println(list);
	}
}
