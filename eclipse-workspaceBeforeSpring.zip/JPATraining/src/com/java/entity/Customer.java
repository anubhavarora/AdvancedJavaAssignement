package com.java.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="customer1")
public class Customer 
{
	@Id
	@GeneratedValue
	@Column(name="cust_id")
	private int customerId;
	
	@Column(name="cust_name", length=20)
	private String custName;
	

	@Column(name="cust_email", length=20)
	private String custEmail;
	
	//For many to many we use join in table instead of columns
	@ManyToMany
	@JoinTable(name="CustomerSubscriptionLink2", joinColumns= {@JoinColumn(name="cid")}, inverseJoinColumns= {@JoinColumn(name="sid")})
	private Set<Subscription> subscriptions = new <Subscription> HashSet();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public Set<Subscription> getSubscriptions() {
		return subscriptions;
	}

	public void setSubscriptions(Set<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}
	
	
	
	
}
