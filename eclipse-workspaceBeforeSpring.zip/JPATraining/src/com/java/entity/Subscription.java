package com.java.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="subscription1")
public class Subscription 
{
	@Id
	@GeneratedValue
	@Column(name="sub_id")
	private int subscriptionId;
	
	@Column(name="sub_name", length=20)
	private String subscriptionName;
	

	@Column(name="sub_duration", length=20)
	private String subscriptionDuration;

//	For many to many we use join in table instead of columns
	@ManyToMany
	@JoinTable(name="CustomerSubscriptionLink2", joinColumns= {@JoinColumn(name="sid")}, inverseJoinColumns= {@JoinColumn(name="cid")})
	private Set<Customer> customers = new <Customer> HashSet();

	public int getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public String getSubscriptionDuration() {
		return subscriptionDuration;
	}

	public void setSubscriptionDuration(String subscriptionDuration) {
		this.subscriptionDuration = subscriptionDuration;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}
	
	
	
}
