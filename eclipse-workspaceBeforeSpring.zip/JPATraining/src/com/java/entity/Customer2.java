package com.java.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="customer2")
public class Customer2 
{
	@Id
	@GeneratedValue
	@Column(name="cust_id")
	private int customerId;
	
	@Column(name="cust_name", length=20)
	private String custName;
	

	@Column(name="cust_email", length=20)
	private String custEmail;
	

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	
}
