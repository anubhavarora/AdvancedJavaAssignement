package com.java.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="passport1")
public class Passport 
{
	@Id
	@Column(name="passport_no")
	@GeneratedValue
	int passportNo;
	
	@Column(name="issued_by", length = 20)
	String issuedBy;
	
	@Column(name="issued_on")
	LocalDate issuedOn;
	
	@Column(name="expiry_on")
	LocalDate expiryOn;
	
	@OneToOne(mappedBy = "passport") // name of variable of Person class
	Person person;

	public int getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public LocalDate getIssuedOn() {
		return issuedOn;
	}

	public void setIssuedOn(LocalDate issuedOn) {
		this.issuedOn = issuedOn;
	}

	public LocalDate getExpiryOn() {
		return expiryOn;
	}

	public void setExpiryOn(LocalDate expiryOn) {
		this.expiryOn = expiryOn;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
	
	
	
}
