package com.java;

import org.junit.jupiter.api.Test;

import com.java.entity.Customer;
import com.java.entity.Subscription;
import com.java.repo.BaseRepository;

public class ManyToManyTesting2 
{
	@Test
	public void addCustomers()
	{
		BaseRepository br = new BaseRepository();
		
		Customer cust1 = new Customer();
		cust1.setCustName("Jack");
		cust1.setCustEmail("Jack@Jack.com");
		
		Customer cust2 = new Customer();
		cust2.setCustName("Rose");
		cust2.setCustEmail("Rose@Rose.com");
		
		Customer cust3 = new Customer();
		cust3.setCustName("Jill");
		cust3.setCustEmail("Jill@Jill.com");
		
		br.persist(cust1);
		br.persist(cust2);
		br.persist(cust3);
		
	}
	
	
	@Test
	public void addSubscriptions()
	{
		BaseRepository br = new BaseRepository();
		
		Subscription sub1 = new Subscription();
		sub1.setSubscriptionName("Netflix");
		sub1.setSubscriptionDuration("6");
		
		Subscription sub2 = new Subscription();
		sub2.setSubscriptionName("Prime Video");
		sub2.setSubscriptionDuration("12");
		
		Subscription sub3 = new Subscription();
		sub3.setSubscriptionName("Zomato");
		sub3.setSubscriptionDuration("3");
		
		br.persist(sub1);
		br.persist(sub2);
		br.persist(sub3);		
	}
	
	@Test
	public void assignExistingSubscriptionToExistingCustomers()
	{
		BaseRepository br = new BaseRepository();
		Customer cust = br.find(Customer.class, 41);
		
		Subscription sub1 = br.find(Subscription.class, 44);
		Subscription sub2 = br.find(Subscription.class, 45);
		
		cust.getSubscriptions().add(sub1);
		cust.getSubscriptions().add(sub2);
		
		br.merge(cust);
		
		/*
		 * Long Method
		 * 
		 	Set<Subscription> mySet = new HashSet<Subscription>();
			mySet.add(sub1);
			mySet.add(sub2);
		
			cust.setSubscriptions(mySet);
		 * 
		 * */
		
	}

}
