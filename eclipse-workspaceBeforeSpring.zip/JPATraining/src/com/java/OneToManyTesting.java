package com.java;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.java.entity.Department;
import com.java.entity.Employee;
import com.java.repo.BaseRepository;

public class OneToManyTesting 
{
	@Test
	public void addNewDepartment()
	{
		BaseRepository br = new BaseRepository();
		
		Department dept = new Department();
		dept.setDepartmentNumber(10);
		dept.setDepartmentName("IT");
		dept.setDepartmentLocation("NY");
		
		br.persist(dept);
	}
	
	@Test
	public void addNewDepartmentWithNewEmployees()
	{
		BaseRepository br = new BaseRepository();
		
		Department dept = new Department();
		dept.setDepartmentNumber(20);
		dept.setDepartmentName("Test");
		dept.setDepartmentLocation("NJ");
		
		Employee emp1 = new Employee(100,"Jack",5000,dept);
		Employee emp2 = new Employee(101,"Jill",5000,dept);
		Employee emp3 = new Employee(102,"Jane",5000,dept);
		
		Set<Employee> myEmp = new HashSet<Employee>();
		myEmp.add(emp1);
		myEmp.add(emp2);
		myEmp.add(emp3);
		
		dept.setStaff(myEmp);
		
		br.merge(dept);
	}
	
	@Test
	public void addNewEmployeesToExistingDepartmentTest()
	{
		BaseRepository br = new BaseRepository();
		
		Department dept = br.find(Department.class, 10);
		
		Employee emp1 = new Employee(500,"Rack",5000,dept);
		Employee emp2 = new Employee(501,"Rill",5000,dept);
		Employee emp3 = new Employee(502,"Rane",5000,dept);
		
		Set<Employee> myEmp = new HashSet<Employee>();
		myEmp.add(emp1);
		myEmp.add(emp2);
		myEmp.add(emp3);
		
		dept.setStaff(myEmp);
		
		br.merge(dept);
	}
	
	@Test
	public void showDepartment()
	{
		BaseRepository br = new BaseRepository();
		Department dept = br.find(Department.class, 10);
		
		System.out.println("Departmnent Number 	: "+dept.getDepartmentNumber());
		System.out.println("Departmnent Name 	: "+dept.getDepartmentName());
		System.out.println("Departmnent Loc 	: "+dept.getDepartmentLocation());
		
		Set<Employee> emps = dept.getStaff();
		
		for(Employee emp : emps)
		{
			System.out.println("Emp Number 	: "+emp.getEmployeeNumber());
			System.out.println("Emp Name 	: "+emp.getEmployeeName());
			System.out.println("Emp Salary 	: "+emp.getSalary());
		}
		
		
	}
	
}
