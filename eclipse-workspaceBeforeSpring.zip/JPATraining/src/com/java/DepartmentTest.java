package com.java;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.entity.Department;

public class DepartmentTest {

	@Test
	public void insertTest() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EMF   : "+emf);
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("EM   : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("et   : "+et);
		
		et.begin();
		
		Department dept = new Department();
		
		dept.setDepartmentNumber(70);
		dept.setDepartmentName("Training");
		dept.setDepartmentLocation("Mumbai");
		em.persist(dept); // InsertQuery
		
		et.commit();
		
	}
	
	@Test
	public void selectTest() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EMF   : "+emf);
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("EM   : "+em);
		
		//EntityTransaction et = em.getTransaction();
		//System.out.println("et   : "+et);
		
//		et.begin();
		
		Department dept = null;
		
		dept = em.find(Department.class, 10);
		
		System.out.println("Dept No : "+dept.getDepartmentNumber());
		System.out.println("Dept Name : "+dept.getDepartmentName());
		System.out.println("Dept Loc : "+dept.getDepartmentLocation());
		
//		et.commit();
		
	}

	@Test
	public void updateTest() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EMF   : "+emf);
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("EM   : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("et   : "+et);
		
		et.begin();
		
		Department dept = null;
		
		dept = em.find(Department.class, 90); //attached object
		
		System.out.println("Dept No : "+dept.getDepartmentNumber());
		System.out.println("Dept Name : "+dept.getDepartmentName());
		System.out.println("Dept Loc : "+dept.getDepartmentLocation());
		
		//setter method is called on attached object
		dept.setDepartmentName("Advanced Java");
		dept.setDepartmentLocation("Borivali");
		
		//Update
		em.merge(dept);
		
		et.commit();
		
	}
	
	@Test
	public void deleteTest() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EMF   : "+emf);
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("EM   : "+em);
		
		EntityTransaction et = em.getTransaction();
		System.out.println("et   : "+et);
		
		et.begin();
		
		Department dept = null;
		
		
		dept = em.find(Department.class, 70); //attached object
		
		Assertions.assertNotNull(dept); 
				
		System.out.println("Dept No : "+dept.getDepartmentNumber());
		System.out.println("Dept Name : "+dept.getDepartmentName());
		System.out.println("Dept Loc : "+dept.getDepartmentLocation());

		//Delete
		em.remove(dept);
		
		et.commit();
		
	}
	
	@Test
	public void selectAllTest() 
	{
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyJPA");
		
		System.out.println("EMF   : "+emf);
		
		EntityManager em = emf.createEntityManager();
		
		System.out.println("EM   : "+em);
		
		//EntityTransaction et = em.getTransaction();
		//System.out.println("et   : "+et);
		
//		et.begin();
		
		Query query = em.createQuery("from Department");
		List<Department> deptList = query.getResultList();
		
		for(Department dept : deptList)
		{
			System.out.println("Dept No : "+dept.getDepartmentNumber());
			System.out.println("Dept Name : "+dept.getDepartmentName());
			System.out.println("Dept Loc : "+dept.getDepartmentLocation());
			System.out.println("----------------------------------------");
		}
		
		
		
//		et.commit();
		
	}


}
