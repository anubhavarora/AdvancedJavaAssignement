package com.java;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.java.entity.Passport;
import com.java.entity.Person;
import com.java.repo.BaseRepository;


public class OneToOneTest 
{
	@Test
	public void insertNewPersonTest()
	{
		BaseRepository br = new BaseRepository();
		
		Person person1 = new Person();
		Person person2 = new Person();
		Person person3 = new Person();
		
		person1.setPersonName("Anubhav");
		person1.setBirthDate(LocalDate.of(1992, 5, 10));
		
		person2.setPersonName("Ankita");
		person2.setBirthDate(LocalDate.of(1992, 4, 12));
		
		person3.setPersonName("Anubhuti");
		person3.setBirthDate(LocalDate.of(1996, 10, 26));
		
		br.persist(person3);
		br.persist(person2);
		br.persist(person1);
		
	}
	
	
	@Test
	public void insertNewPassportTest()
	{
		BaseRepository br = new BaseRepository();
		
		Passport pass1 = new Passport();
		Passport pass2 = new Passport();
		Passport pass3 = new Passport();
		
		pass1.setIssuedBy("GOI");
		pass1.setIssuedOn(LocalDate.of(2021, 12, 10));
		pass1.setExpiryOn(LocalDate.of(2031, 12, 10));
		
		pass2.setIssuedBy("GOI");
		pass2.setIssuedOn(LocalDate.of(2021, 12, 10));
		pass2.setExpiryOn(LocalDate.of(2031, 12, 10));
		
		pass3.setIssuedBy("GOI");
		pass3.setIssuedOn(LocalDate.of(2021, 12, 10));
		pass3.setExpiryOn(LocalDate.of(2031, 12, 10));
		
		br.persist(pass1);
		br.persist(pass2);
		br.persist(pass3);
	}
	
	@Test
	public void assignExistingPassportToExistingPersonTest()
	{
		BaseRepository br = new BaseRepository();
		
		Person person = br.find(Person.class,17);
		
		Passport passport = br.find(Passport.class,20);
		
		person.setPassport(passport);
		
		br.merge(person);
		
	}
	
	
	@Test
	public void assignExistingPersonToExistingPassportTest()
	{
		BaseRepository br = new BaseRepository();
		
		Person person = br.find(Person.class,17);
		
		Passport passport = br.find(Passport.class,20);
		
		passport.setPerson(person);
		
		br.merge(passport);
		
	}
	
	
	@Test
	public void assignBothExistingPersonToExistingPassportTest() {
		
		BaseRepository br = new BaseRepository();
		
		Person person = br.find(Person.class, 19);
		
		
		Passport passport = br.find(Passport.class, 22);
		
		
		person.setPassport(passport); //setting the fk
		
		passport.setPerson(person);
		
		br.merge(person);
		br.merge(passport);
		
		
		
	}
	
	@Test
	public void addNewPersonWithNewPassportTest()
	{

		BaseRepository br = new BaseRepository();
		
		Person person1 = new Person();
		person1.setPersonName("Jack");
		person1.setBirthDate(LocalDate.of(1992, 5, 10));
		
		Passport pass1 = new Passport();
		
		pass1.setIssuedBy("Govt of Nepal");
		pass1.setIssuedOn(LocalDate.of(2021, 12, 10));
		pass1.setExpiryOn(LocalDate.of(2031, 12, 10));
		
		person1.setPassport(pass1);
//		pass1.setPerson(person1);
		
		br.persist(person1);
//		br.persist(pass1);
		
	}
	
	
	
}
