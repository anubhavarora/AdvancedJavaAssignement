package com.java;

import org.junit.jupiter.api.Test;

import com.java.entity.Department;

import com.java.service.DepartmentServiceImpl;

public class DeptServiceTesting 
{
	DepartmentServiceImpl dri = new DepartmentServiceImpl();
	
	@Test
	void insertDepartment()
	{
		Department dept = new Department();
		dept.setDepartmentNumber(55);
		dept.setDepartmentName("Test");
		dept.setDepartmentLocation("Location");
		dri.addDepartmentService(dept,"user");
	}
	

}
