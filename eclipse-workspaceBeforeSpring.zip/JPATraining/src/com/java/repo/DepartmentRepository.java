package com.java.repo;

import java.util.List;

import com.java.entity.Department;

public interface DepartmentRepository 
{
	void insertDepartment(Department dept);
	void updateDepartment(Department dept);
	void deleteDepartment(int deptno);
	Department selectDepartment(int deptno);
	List<Department> selectDepartments();
}
