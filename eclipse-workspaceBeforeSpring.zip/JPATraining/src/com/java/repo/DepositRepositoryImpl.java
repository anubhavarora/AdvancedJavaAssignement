package com.java.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;

import com.java.entity.Department;

public class DepositRepositoryImpl implements DepartmentRepository 
{

	List<Department> deptList = new ArrayList<Department>();
	
	EntityManager em;
	
	public DepositRepositoryImpl()
	{
		EntityManagerFactory emf =	Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Entity Manager Factory : "+emf);
		
		em = emf.createEntityManager();
		System.out.println("Entity manager : "+em);
	}

	@Override
	public void insertDepartment(Department dept) 
	{
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		em.persist(dept);
		transaction.commit();
	}

	@Override
	public void updateDepartment(Department dept)
	{
		EntityTransaction transaction = em.getTransaction();
		transaction.begin();
		em.merge(dept);
		transaction.commit();
	}

	@Override
	public void deleteDepartment(int deptno) 
	{

		EntityTransaction et = em.getTransaction();
		System.out.println("et   : "+et);
		
		et.begin();
		
		Department dept = em.find(Department.class, deptno);

		em.remove(dept);
		
		et.commit();
		
	
	}

	@Override
	public Department selectDepartment(int deptno) 
	{

		Department dept = em.find(Department.class, deptno);
		return dept;
	
	}

	@Override
	public List<Department> selectDepartments() 
	{

		Query query = em.createQuery("from Department");
		List<Department> deptList = query.getResultList();
		
		return deptList;
	
	}
	
}
