package com.java.service;

import com.java.entity.Department;

public interface DepartmentService 
{
	public void addDepartmentService(Department dept, String username);
	
}
