package com.java;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.entity.Department;
import com.java.repo.DepositRepositoryImpl;

public class DepartmentTest2 
{
	DepositRepositoryImpl dri = new DepositRepositoryImpl();
	
	@Test
	public void Test1_insertTest() 
	{
		Department dept = new Department();
		dept.setDepartmentNumber(90);
		dept.setDepartmentName("Test");
		dept.setDepartmentLocation("Location");
		dri.insertDepartment(dept);
	}
	
	@Test
	public void Test2_selectTest() 
	{
		Department dept = dri.selectDepartment(90);
		System.out.println("DEPTNO : "+dept.getDepartmentNumber());
		System.out.println("DNAME  : "+dept.getDepartmentName());
		System.out.println("DLOC   : "+dept.getDepartmentLocation());
	}

	@Test
	public void updateTest() 
	{
		Department dept = new Department();
		dept.setDepartmentNumber(90);
		dept.setDepartmentName("FUN");
		dept.setDepartmentLocation("BORIVALI");

		dri.updateDepartment(dept);
	}
	
	
	@Test
	public void Test3_selectTest() 
	{
		Department dept = dri.selectDepartment(90);
		System.out.println("DEPTNO : "+dept.getDepartmentNumber());
		System.out.println("DNAME  : "+dept.getDepartmentName());
		System.out.println("DLOC   : "+dept.getDepartmentLocation());
	}
	
	@Test
	public void Test4_deleteTest() 
	{
		dri.deleteDepartment(90);
	}
	
	@Test
	public void Test5_selectAllTest() 
	{
		List<Department> deptList = dri.selectDepartments();
		for(Department dept : deptList) {
			System.out.println("DEPTNO : "+dept.getDepartmentNumber());
			System.out.println("DNAME  : "+dept.getDepartmentName());
			System.out.println("DLOC   : "+dept.getDepartmentLocation());
			System.out.println("-------------------");
		}
	}


}
