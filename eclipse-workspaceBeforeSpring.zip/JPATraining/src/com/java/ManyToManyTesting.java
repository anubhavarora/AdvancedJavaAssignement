package com.java;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import com.java.entity.Customer2;
import com.java.entity.CustomerSubscriptionLink;
import com.java.entity.Subscription2;
import com.java.repo.BaseRepository;

public class ManyToManyTesting 
{
	@Test
	public void addCustomersAddSubscriptions()
	{
		BaseRepository br = new BaseRepository();
		
		Customer2 cust1 = new Customer2();
		cust1.setCustName("Anita");
		cust1.setCustEmail("Jack@Jack.com");
		
		Customer2 cust2 = new Customer2();
		cust2.setCustName("Geeta");
		cust2.setCustEmail("Rose@Rose.com");
		
		Customer2 cust3 = new Customer2();
		cust3.setCustName("Veena");
		cust3.setCustEmail("Jill@Jill.com");
		
		br.persist(cust1);
		br.persist(cust2);
		br.persist(cust3);
		
		Subscription2 sub1 = new Subscription2();
		sub1.setSubscriptionName("Magazine");
		sub1.setSubscriptionDuration("6");
		
		Subscription2 sub2 = new Subscription2();
		sub2.setSubscriptionName("CD");
		sub2.setSubscriptionDuration("12");
		
		Subscription2 sub3 = new Subscription2();
		sub3.setSubscriptionName("DVD");
		sub3.setSubscriptionDuration("3");
		
		br.persist(sub1);
		br.persist(sub2);
		br.persist(sub3);
		
	}
	
	
	@Test
	public void assignExistingSubscriptionsToExistingCustomers()
	{
		BaseRepository br = new BaseRepository();
		Customer2 cust = br.find(Customer2.class, 48);
		
		Subscription2 sub1 = br.find(Subscription2.class, 51);
		Subscription2 sub2 = br.find(Subscription2.class, 52);
		
		CustomerSubscriptionLink csl = new CustomerSubscriptionLink();
		
		csl.setSubscriptionDate(LocalDate.now());
		csl.setSubscription(sub1);
		csl.setCustomer(cust);
		
		br.merge(csl);
		
		
				
	}
	

}
