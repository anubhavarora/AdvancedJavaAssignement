package com.example.demo.repository.exceptions;

public class FlightAlreadyPresentException extends Exception {

	public FlightAlreadyPresentException(String message) {
		super(message);
		
	}

	
}
