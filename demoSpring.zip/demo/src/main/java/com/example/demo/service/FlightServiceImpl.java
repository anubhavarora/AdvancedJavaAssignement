package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Flight;
import com.example.demo.repository.FlightRepository;
import com.example.demo.repository.exceptions.FlightAlreadyPresentException;
import com.example.demo.repository.exceptions.FlightNotFoundException;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	@Qualifier("flightRepoImpl3")
	FlightRepository fr;

	public List<Flight> getAvailableFlightsService() {
		List<Flight> flightList = fr.getAvailableFlights();

		for (Flight theFlight : flightList) {
			System.out.println("Flight Number : " + theFlight.getFlightNumber());
			System.out.println("Flight Source : " + theFlight.getSource());
			System.out.println("Flight Destin : " + theFlight.getDestination());
			System.out.println("Flight Date   : " + theFlight.getDepartureDate());
			System.out.println("-------------------");
		}

		return flightList;
	}

	@Override
	public Flight getFlightService(int flno) {
		return fr.getFlight(flno);
	}

	@Override
	public Flight addFlight(Flight flight) throws FlightAlreadyPresentException
	{
		try 
		{
			fr.insertFlight(flight);
		} 
		catch (FlightAlreadyPresentException e) 
		{
			throw e;
		}
		return flight;
	}

	@Override
	public Flight modifyFlightService(Flight flight) throws FlightNotFoundException 
	{
		try 
		{
			fr.updateFlight(flight);
		} 
		catch (FlightNotFoundException e) 
		{
			throw e;
		}
		
		return flight;
	}

	@Override
	public void removeFlightService(int flightNumber) throws FlightNotFoundException 
	{
		try 
		{
			fr.deleteFlight(flightNumber);
		} 
		catch (FlightNotFoundException e) 
		{
			throw e;
		}
	}

}
