package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Flight;
import com.example.demo.repository.exceptions.FlightAlreadyPresentException;
import com.example.demo.repository.exceptions.FlightNotFoundException;

public interface FlightService 
{
	public List<Flight> getAvailableFlightsService();
	
	public Flight getFlightService(int flno);
	
	public Flight addFlight(Flight flight) throws FlightAlreadyPresentException;
	
	public Flight modifyFlightService(Flight flight) throws FlightNotFoundException;
	
	public void removeFlightService(int flightNumber) throws FlightNotFoundException;

}
