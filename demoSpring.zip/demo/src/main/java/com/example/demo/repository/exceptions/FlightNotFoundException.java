package com.example.demo.repository.exceptions;

public class FlightNotFoundException extends Exception {

	

	public FlightNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
