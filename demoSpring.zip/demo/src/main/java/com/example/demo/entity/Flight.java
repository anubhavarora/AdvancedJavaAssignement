package com.example.demo.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flight_details")
public class Flight {

	@Id
	@Column(name="flno")
	private int flightNumber;
	
	@Column(name="source",length=20)
	private String source;
	
	@Column(name="target",length=20)
	private String destination;
	
	@Column(name="departure")
	private LocalDate departureDate;

	
	
	
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Flight(int flightNumber, String source, String destination, LocalDate departureDate) {
		super();
		this.flightNumber = flightNumber;
		this.source = source;
		this.destination = destination;
		this.departureDate = departureDate;
	}

	public int getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(LocalDate departureDate) {
		this.departureDate = departureDate;
	}
	
	
	
}
