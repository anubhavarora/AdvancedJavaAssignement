package com.example.demo.service;

import com.example.demo.entity.Flight;

public class ResponseStatus 
{
	private String responseMessage;
	private Flight flight;
	
	
	public ResponseStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public ResponseStatus(String responseMessage, Flight flight) {
		super();
		this.responseMessage = responseMessage;
		this.flight = flight;
	}






	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	
	

}
