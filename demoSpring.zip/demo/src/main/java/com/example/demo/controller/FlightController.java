package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Flight;
import com.example.demo.repository.exceptions.FlightAlreadyPresentException;
import com.example.demo.repository.exceptions.FlightNotFoundException;
import com.example.demo.service.FlightService;
import com.example.demo.service.ResponseStatus;

@RestController
@RequestMapping("/flight") // Parent URI
public class FlightController {
	@RequestMapping("/greet") // Child URI
	public String greeting() {
		// http://localhost:8080/flight/greet
		return "<h1>Welcome to Flight Booking System</h1>";
	}

	@Autowired
	FlightService fs;

	@RequestMapping("/getFlights")
	public List<Flight> getFlights() {
		return fs.getAvailableFlightsService();
	}

	@RequestMapping("/getFlight/{flno}")
	public Flight getFlight(@PathVariable("flno") int flightNumber) {
		return fs.getFlightService(flightNumber);
	}

	@PostMapping("/addFlight")
	public ResponseStatus getFlight(@RequestBody Flight flight) 
	{
		ResponseStatus rStatus = new ResponseStatus();
		try 
		{
			fs.addFlight(flight);
			rStatus.setFlight(flight);
			rStatus.setResponseMessage("Flight has been Added");
		} 
		catch (FlightAlreadyPresentException e) 
		{
			rStatus.setFlight(null);
			rStatus.setResponseMessage(e.getMessage());
		}
		
		return rStatus;
	}
	
	@PostMapping("/updateFlight")
	public ResponseStatus modifyFlight(@RequestBody Flight flight) 
	{
		ResponseStatus rStatus = new ResponseStatus();
		try 
		{
			fs.modifyFlightService(flight);
			rStatus.setFlight(flight);
			rStatus.setResponseMessage("Flight has been Updated");
		} 
		catch (FlightNotFoundException e) 
		{
			rStatus.setFlight(null);
			rStatus.setResponseMessage(e.getMessage());
		}
		
		return rStatus;
	}
	
	@PostMapping("/deleteFlight/{flno}")
	public ResponseStatus removeFlight(@PathVariable("flno") int flightNumber)
	{
		ResponseStatus rStatus = new ResponseStatus();
		
		try 
		{
			fs.removeFlightService(flightNumber);
			rStatus.setResponseMessage("Flight has been deleted");
		} 
		catch (FlightNotFoundException e) 
		{
			rStatus.setResponseMessage(e.getMessage());
		}
		
		return rStatus;
	}
	

}
